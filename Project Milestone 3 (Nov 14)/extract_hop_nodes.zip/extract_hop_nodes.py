def extract_hop_nodes(paths_df):
    """
    Extract hop-level neighbor sets from GraphFrames BFS result.

    Input:
        paths_df (DataFrame): DataFrame returned from GraphFrames BFS.

    Returns:
        HopDict
    """
    HopDict = {}

    for col_name in paths_df.columns:
        if col_name.startswith("v"):
            # Extract hop number from column name, e.g., "v2" -> 2
            hop = int(col_name[1:])

            # Collect distinct, non-null node IDs for this hop
            nodes = (
                paths_df.select(col_name)
                        .distinct()
                        .na.drop()
                        .rdd.flatMap(lambda x: x)
                        .collect()
            )

            HopDict[hop] = nodes

    return HopDict
