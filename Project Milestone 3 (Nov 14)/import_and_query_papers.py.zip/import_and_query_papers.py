import csv
import os
import sys
import time
from neo4j import GraphDatabase, basic_auth
from tqdm import tqdm
import matplotlib.pyplot as plt

# === Configuration ===
NEO4J_URI = "neo4j://127.0.0.1:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "project415"
CSV_PATH = "citation_network.csv"  # Path to the CSV file
BATCH_SIZE = 500
OUTPUT_DIR = "paper_query_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# === Helpers ===
def safe_int(val):
    try:
        return int(float(val))
    except Exception:
        return None

def clean_row(row):
    return {
        "paper_id": row.get("id") or "",
        "title": row.get("title") or "",
        "year": safe_int(row.get("year")),
        "n_citation": safe_int(row.get("n_citation")) or 0,
        "doc_type": row.get("doc_type") or "",
        "reference_count": safe_int(row.get("reference_count")) or 0,
        "references": row.get("references") or "",
        "doi": row.get("doi") or ""
    }

def create_constraint(tx):
    tx.run("""
        CREATE CONSTRAINT unique_paper_id IF NOT EXISTS
        FOR (p:Paper) REQUIRE p.paper_id IS UNIQUE;
    """)

def import_papers_batch(tx, batch):
    cypher = """
    UNWIND $batch AS row
    MERGE (p:Paper {paper_id: row.paper_id})
    SET p.title = row.title,
        p.year = coalesce(row.year, p.year),
        p.n_citation = row.n_citation,
        p.doc_type = row.doc_type,
        p.reference_count = row.reference_count,
        p.doi = row.doi
    """
    tx.run(cypher, batch=batch)

def import_cites_batch(tx, cites):
    cypher = """
    UNWIND $cites AS pair
    MERGE (a:Paper {paper_id: pair.from_id})
    MERGE (b:Paper {paper_id: pair.to_id})
    MERGE (a)-[:CITES]->(b)
    """
    tx.run(cypher, cites=cites)

def run_query_and_save(tx, query, out_txt_path):
    result = tx.run(query)
    rows = []
    for rec in result:
        rows.append(tuple(rec.values()))
    with open(out_txt_path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(", ".join([str(x) for x in r]) + "\n")
    return rows

def save_simple_png(num, label, path):
    plt.figure(figsize=(4,3))
    plt.bar([label], [num])
    plt.title(f"{label}: {num}")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(path)
    plt.close()

# === Main ===
def main():
    if not os.path.exists(CSV_PATH):
        print(f"ERROR: CSV file not found: {CSV_PATH}", file=sys.stderr)
        sys.exit(1)

    driver = GraphDatabase.driver(NEO4J_URI, auth=basic_auth(NEO4J_USER, NEO4J_PASSWORD))

    with driver.session() as session:
        # Create uniqueness constraint
        session.execute_write(create_constraint)

        # Read CSV and import nodes & relationships
        papers_batch = []
        cite_pairs = []
        imported_nodes = 0
        start_time = time.perf_counter()

        print("Importing Papers from CSV...")
        with open(CSV_PATH, newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in tqdm(reader, desc="Rows processed"):
                paper = clean_row(row)
                if not paper["paper_id"]:
                    continue
                papers_batch.append(paper)

                # process references
                refs = [r.strip() for r in paper["references"].split(";") if r.strip()]
                for rid in refs:
                    cite_pairs.append({"from_id": paper["paper_id"], "to_id": rid})

                if len(papers_batch) >= BATCH_SIZE:
                    session.execute_write(import_papers_batch, papers_batch)
                    imported_nodes += len(papers_batch)
                    papers_batch = []

                if len(cite_pairs) >= BATCH_SIZE:
                    session.execute_write(import_cites_batch, cite_pairs)
                    cite_pairs = []

            # flush remaining
            if papers_batch:
                session.execute_write(import_papers_batch, papers_batch)
                imported_nodes += len(papers_batch)
            if cite_pairs:
                session.execute_write(import_cites_batch, cite_pairs)

        end_time = time.perf_counter()
        print(f"Imported {imported_nodes} Paper nodes in {end_time-start_time:.2f} seconds")

        # === Queries ===
        # Q1: Total papers
        q1 = "MATCH (p:Paper) RETURN count(p) AS total_papers"
        rows1 = session.execute_read(run_query_and_save, q1, os.path.join(OUTPUT_DIR, "q1_count_all_papers.txt"))
        save_simple_png(rows1[0][0], "All Papers", os.path.join(OUTPUT_DIR, "q1_count_all_papers.png"))

        # Q2: Highly cited (n_citation >= 10)
        q2 = """
        MATCH (p:Paper)
        WHERE p.n_citation >= 10
        RETURN p.paper_id, p.title, p.n_citation
        ORDER BY p.n_citation DESC
        LIMIT 200
        """
        rows2 = session.execute_read(run_query_and_save, q2, os.path.join(OUTPUT_DIR, "q2_highly_cited_papers.txt"))
        save_simple_png(len(rows2), "Highly Cited", os.path.join(OUTPUT_DIR, "q2_count_highly_cited.png"))

        # Q3: Conference papers count
        q3 = "MATCH (p:Paper) WHERE toLower(coalesce(p.doc_type,'')) = 'conference' RETURN count(p) AS conference_count"
        rows3 = session.execute_read(run_query_and_save, q3, os.path.join(OUTPUT_DIR, "q3_count_conference_papers.txt"))
        save_simple_png(rows3[0][0], "Conference Papers", os.path.join(OUTPUT_DIR, "q3_count_conference_papers.png"))

        print(f"Query results saved in {OUTPUT_DIR}")

    driver.close()

if __name__ == "__main__":
    main()
