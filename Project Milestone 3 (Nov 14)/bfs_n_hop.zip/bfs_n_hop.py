from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, split, trim
from graphframes import GraphFrame


def create_spark_session():
    spark = SparkSession.builder \
        .appName("BFS_N_Hop_Search") \
        .config("spark.jars.packages", "graphframes:graphframes:0.8.2-spark3.2-s_2.12") \
        .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")
    return spark


def load_citation_network(spark, csv_path):
    print("Loading citation network from CSV...")

    df = spark.read.csv(csv_path, header=True, inferSchema=True)

    print("Creating vertices DataFrame...")
    vertices_df = df.select("id").distinct()

    print("Creating edges DataFrame...")

    edges_df = df.select(
        col("id").alias("src"),
        explode(split(col("references"), ";")).alias("dst")
    ).filter(
        col("dst").isNotNull() & (trim(col("dst")) != "")
    )

    edges_df = edges_df.select(
        col("src").cast("string"),
        trim(col("dst")).cast("string").alias("dst")
    ).filter(
        col("src").isNotNull() & col("dst").isNotNull()
    )

    edges_df = edges_df.filter(col("src") != col("dst"))

    print(f"Vertices count: {vertices_df.count()}")
    print(f"Edges count: {edges_df.count()}")

    return vertices_df, edges_df


def bfs_n_hops(G, start_node, N):
    """Run BFS up to N hops from start_node."""
    from_expr = f"id = '{start_node}'"
    to_expr = "id IS NOT NULL"

    print(f"Running BFS from node {start_node} with max path length {N}...")

    paths = G.bfs(
        fromExpr=from_expr,
        toExpr=to_expr,
        maxPathLength=N
    )

    return paths


def main(csv_path, start_node, N):
    """Main function for use in Colab / notebook."""
    spark = create_spark_session()
    try:
        vertices_df, edges_df = load_citation_network(spark, csv_path)
        print("Creating GraphFrame...")
        G = GraphFrame(vertices_df, edges_df)

        print(f"\n{'='*60}")
        print(f"BFS N-Hop Search Results")
        print(f"{'='*60}")
        paths = bfs_n_hops(G, start_node, N)

        print(f"\nTotal paths found: {paths.count()}")
        print("\nSample paths (first 20):")
        paths.show(20, truncate=False)

    finally:
        spark.stop()


csv_path = "/content/citation_network_reduced.csv"
start_node = "2471944230"
N = 3

main(csv_path, start_node, N)